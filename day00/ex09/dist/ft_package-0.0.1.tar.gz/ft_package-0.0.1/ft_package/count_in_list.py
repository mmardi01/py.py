

def count_in_list(lst: list, el):
    count = 0
    for x in lst:
        if x == el:
            count += 1
    return count
